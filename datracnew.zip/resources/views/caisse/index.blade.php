@extends ('layouts.hopital.caisse')
@section ('contenu')
<div class="container-fluid">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-6 col-md-8 col-sm-12">
                        <h2><a href="javascript:void(0);" class="btn btn-xs btn-link btn-toggle-fullwidth"><i class="fa fa-arrow-left"></i></a> Caisse</h2>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/index"><i class="icon-home"></i></a></li>                            
                            <li class="breadcrumb-item active">Identification Patient</li>
                        </ul>
                    </div>            
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-md-12">
                    <div class="card">
                        <div class="body">
                            <div class="input-group" id="adv-search">
                                <input type="text" class="form-control" placeholder="Rechercher Ici..." />
                                <div class="input-group-btn">
                                    <div class="btn-group" role="group">
                                        <div class="dropdown dropdown-lg">
                                            <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><span class="caret"></span></button>
                                            <div class="dropdown-menu dropdown-menu-right" role="menu">
                                                <form class="form-horizontal">
                                                    <div class="form-group">
                                                    <label>Filtrer par</label>
                                                    <select class="form-control">
                                                        <option value="0" selected>Sélection par</option>
                                                        <option value="1">Nom du Titulaire</option>
                                                        <option value="2">Numéro d'Identification</option>
                                                        <option value="3">Ayant-Droit</option>
                                                    </select>
                                                    </div>
                                                    <button type="submit" class="btn btn-primary btn-block">Rechercher</button>
                                                </form>
                                            </div>
                                        </div>
                                        <button type="button" class="btn btn-primary"><span class="icon-magnifier" aria-hidden="true"></span></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="body">                            
                            <ul class="nav nav-tabs-new m-b-20">
                                <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#cnamgs">CNAMGS</a></li>
                                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#ascoma">ASCOMA</a></li>
                                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#sunu">SUNU</a></li>
                                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#sanlam">SANLAM</a></li>
                                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#beneficial">BENEFICIAL</a></li>
                                <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#axa">AXA</a></li>                               
                            </ul>                        
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlTextarea1" class="form-label">Résultat Recherche </label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div>
                    </div>                
                </div>
            </div>

        </div>
@endsection