<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});
Route::get('/dashboard', function () {
    return view('dashboard');
})->name('dashboardAssurance')->middleware('role');

Route::get('/dashboard/utilisateurs', function () {
    return view('utilisateurs');
})->name('users');

Route::get('/dashboard/assures', function () {
    return view('dashboard/assurances/assures/assures');
})->name('assures-list')->middleware('role');

Route::get('/dashboard/add-assure', function () {
    return view('dashboard/assurances/assures/add-assure');
})->name('assure-add')->middleware('role');
Route::post('/dashboard/add-assure', 'AssureController@store')->name('add-assure-post')->middleware('role');

Route::get('/dashboard/caisiere', function () {
    return view('search');
})->name('search');

Route::get('/caisse', function () {
    return view('caisse/index');
});

Route::get('/doctor', function () {
    return view('doctor/index');
});

Route::get('/suivi-patient', function () {
    return view('doctor/suivi-patient');
});

Route::get('/doctor-chat', function () {
    return view('doctor/doctor-chat');
});

Route::get('/rendez-vous', function () {
    return view('doctor/rendez-vous');
});

Route::get('/rendezvous', function () {
    return view('caisse/rendezvous');
});

Route::get('/paiement', function () {
    return view('caisse/paiement');
});

Route::get('/add-paiement', function () {
    return view('caisse/add-paiement');
});

Route::get('/add-doctor', function () {
    return view('admin/add-doctor');
});


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
