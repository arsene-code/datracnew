<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Appareillage extends Model
{
    //
}
