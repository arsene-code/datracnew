<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmploiTemps extends Model
{
    //
}
