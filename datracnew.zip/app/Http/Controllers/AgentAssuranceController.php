<?php

namespace App\Http\Controllers;

use App\AgentAssurance;
use Illuminate\Http\Request;

class AgentAssuranceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AgentAssurance  $agentAssurance
     * @return \Illuminate\Http\Response
     */
    public function show(AgentAssurance $agentAssurance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AgentAssurance  $agentAssurance
     * @return \Illuminate\Http\Response
     */
    public function edit(AgentAssurance $agentAssurance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AgentAssurance  $agentAssurance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AgentAssurance $agentAssurance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AgentAssurance  $agentAssurance
     * @return \Illuminate\Http\Response
     */
    public function destroy(AgentAssurance $agentAssurance)
    {
        //
    }
}
