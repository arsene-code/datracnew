<?php

namespace App\Http\Controllers;

use App\PrestationAssurance;
use Illuminate\Http\Request;

class PrestationAssuranceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PrestationAssurance  $prestationAssurance
     * @return \Illuminate\Http\Response
     */
    public function show(PrestationAssurance $prestationAssurance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PrestationAssurance  $prestationAssurance
     * @return \Illuminate\Http\Response
     */
    public function edit(PrestationAssurance $prestationAssurance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PrestationAssurance  $prestationAssurance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PrestationAssurance $prestationAssurance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PrestationAssurance  $prestationAssurance
     * @return \Illuminate\Http\Response
     */
    public function destroy(PrestationAssurance $prestationAssurance)
    {
        //
    }
}
