<?php

namespace App\Http\Controllers;

use App\FaireExamen;
use Illuminate\Http\Request;

class FaireExamenController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\FaireExamen  $faireExamen
     * @return \Illuminate\Http\Response
     */
    public function show(FaireExamen $faireExamen)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\FaireExamen  $faireExamen
     * @return \Illuminate\Http\Response
     */
    public function edit(FaireExamen $faireExamen)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\FaireExamen  $faireExamen
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FaireExamen $faireExamen)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\FaireExamen  $faireExamen
     * @return \Illuminate\Http\Response
     */
    public function destroy(FaireExamen $faireExamen)
    {
        //
    }
}
