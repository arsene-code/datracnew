<?php

namespace App\Http\Controllers;

use App\AppareillageAssurance;
use Illuminate\Http\Request;

class AppareillageAssuranceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AppareillageAssurance  $appareillageAssurance
     * @return \Illuminate\Http\Response
     */
    public function show(AppareillageAssurance $appareillageAssurance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AppareillageAssurance  $appareillageAssurance
     * @return \Illuminate\Http\Response
     */
    public function edit(AppareillageAssurance $appareillageAssurance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AppareillageAssurance  $appareillageAssurance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AppareillageAssurance $appareillageAssurance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AppareillageAssurance  $appareillageAssurance
     * @return \Illuminate\Http\Response
     */
    public function destroy(AppareillageAssurance $appareillageAssurance)
    {
        //
    }
}
