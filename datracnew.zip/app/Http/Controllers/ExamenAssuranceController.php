<?php

namespace App\Http\Controllers;

use App\ExamenAssurance;
use Illuminate\Http\Request;

class ExamenAssuranceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ExamenAssurance  $examenAssurance
     * @return \Illuminate\Http\Response
     */
    public function show(ExamenAssurance $examenAssurance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ExamenAssurance  $examenAssurance
     * @return \Illuminate\Http\Response
     */
    public function edit(ExamenAssurance $examenAssurance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ExamenAssurance  $examenAssurance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ExamenAssurance $examenAssurance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ExamenAssurance  $examenAssurance
     * @return \Illuminate\Http\Response
     */
    public function destroy(ExamenAssurance $examenAssurance)
    {
        //
    }
}
