<?php

namespace App\Http\Controllers;

use App\SuiviFiche;
use Illuminate\Http\Request;

class SuiviFicheController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SuiviFiche  $suiviFiche
     * @return \Illuminate\Http\Response
     */
    public function show(SuiviFiche $suiviFiche)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SuiviFiche  $suiviFiche
     * @return \Illuminate\Http\Response
     */
    public function edit(SuiviFiche $suiviFiche)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SuiviFiche  $suiviFiche
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SuiviFiche $suiviFiche)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SuiviFiche  $suiviFiche
     * @return \Illuminate\Http\Response
     */
    public function destroy(SuiviFiche $suiviFiche)
    {
        //
    }
}
