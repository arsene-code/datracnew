<?php

namespace App\Http\Controllers;

use App\MedicamentAssurance;
use Illuminate\Http\Request;

class MedicamentAssuranceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MedicamentAssurance  $medicamentAssurance
     * @return \Illuminate\Http\Response
     */
    public function show(MedicamentAssurance $medicamentAssurance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MedicamentAssurance  $medicamentAssurance
     * @return \Illuminate\Http\Response
     */
    public function edit(MedicamentAssurance $medicamentAssurance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MedicamentAssurance  $medicamentAssurance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MedicamentAssurance $medicamentAssurance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MedicamentAssurance  $medicamentAssurance
     * @return \Illuminate\Http\Response
     */
    public function destroy(MedicamentAssurance $medicamentAssurance)
    {
        //
    }
}
