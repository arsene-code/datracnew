<?php

namespace App\Http\Controllers;

use App\TicketModerateur;
use Illuminate\Http\Request;

class TicketModerateurController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TicketModerateur  $ticketModerateur
     * @return \Illuminate\Http\Response
     */
    public function show(TicketModerateur $ticketModerateur)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TicketModerateur  $ticketModerateur
     * @return \Illuminate\Http\Response
     */
    public function edit(TicketModerateur $ticketModerateur)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TicketModerateur  $ticketModerateur
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TicketModerateur $ticketModerateur)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TicketModerateur  $ticketModerateur
     * @return \Illuminate\Http\Response
     */
    public function destroy(TicketModerateur $ticketModerateur)
    {
        //
    }
}
