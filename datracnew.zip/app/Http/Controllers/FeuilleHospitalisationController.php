<?php

namespace App\Http\Controllers;

use App\FeuilleHospitalisation;
use Illuminate\Http\Request;

class FeuilleHospitalisationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\FeuilleHospitalisation  $feuilleHospitalisation
     * @return \Illuminate\Http\Response
     */
    public function show(FeuilleHospitalisation $feuilleHospitalisation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\FeuilleHospitalisation  $feuilleHospitalisation
     * @return \Illuminate\Http\Response
     */
    public function edit(FeuilleHospitalisation $feuilleHospitalisation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\FeuilleHospitalisation  $feuilleHospitalisation
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FeuilleHospitalisation $feuilleHospitalisation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\FeuilleHospitalisation  $feuilleHospitalisation
     * @return \Illuminate\Http\Response
     */
    public function destroy(FeuilleHospitalisation $feuilleHospitalisation)
    {
        //
    }
}
