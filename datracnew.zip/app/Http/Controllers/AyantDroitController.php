<?php

namespace App\Http\Controllers;

use App\AyantDroit;
use Illuminate\Http\Request;

class AyantDroitController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AyantDroit  $ayantDroit
     * @return \Illuminate\Http\Response
     */
    public function show(AyantDroit $ayantDroit)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AyantDroit  $ayantDroit
     * @return \Illuminate\Http\Response
     */
    public function edit(AyantDroit $ayantDroit)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AyantDroit  $ayantDroit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AyantDroit $ayantDroit)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AyantDroit  $ayantDroit
     * @return \Illuminate\Http\Response
     */
    public function destroy(AyantDroit $ayantDroit)
    {
        //
    }
}
