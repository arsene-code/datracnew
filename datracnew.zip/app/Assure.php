<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Assure extends Model
{
    //
}
