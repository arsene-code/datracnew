<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TypeEtablissement extends Model
{
    //
}
